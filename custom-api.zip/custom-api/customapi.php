<?php
/* @wordpress-plugin
 * Plugin Name:       Custom API's
 * Description:       All functions which is used in an api.
 * Version:           1.0
 * Author:            Admin
 */
// If this file is called directly, abort.
/* Start 09-03-2023 code */
if(!defined('WPINC')){
    die;
}
/*path http://localhost/logo/wp-json/customapi/v1/userdata?userID=1*/
add_action('rest_api_init', function(){
    remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
    add_filter('rest_pre_serve_request', function ($value) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET');
        header('Access-Control-Allow-Credentials: true');
        return $value;
    });
 
    
    register_rest_route( 'customapi/v1/', '/showFavorites', array( // Api Url
       'methods'    => 'GET', // Api Method
       'callback'   => 'showFavorites_callback'  // Goto Function
    ));

    register_rest_route( 'customapi/v1', '/userdata', array(
        'methods' => 'GET',
        'callback' => 'showFavorites_callback_userdata',
    ));

    register_rest_route( 'customapi/v1', '/updateprofile', array(
    'methods' => 'POST',
    'callback' => 'showFavorites_callback_updateprofile',
    ));

    register_rest_route( 'customapi/v1', '/passwordreset', array(
    'methods' => 'POST',
    'callback' => 'showFavorites_callback_passwordreset',
    ));

     register_rest_route( 'customapi/v1', '/login', array(
    'methods' => 'POST',
    'callback' => 'showFavorites_callback_login',
    ));


 register_rest_route( 'customapi/v1', '/productlist', array(
    'methods' => 'GET',
    'callback' => 'showFavorites_callback_productlis',
    ));

 register_rest_route( 'customapi/v1', '/categorylist', array(
    'methods' => 'GET',
    'callback' => 'showFavorites_callback_categorylist',
    ));

});

/*User Login api in wp start function in wp */
function showFavorites_callback_login($request_data){
    global $wpdb;
    $parameters = $request_data->get_params();
    $user_login = $parameters['user_login'];
    $password = $parameters['password'];

    $creds = array(
    'user_login'    => $user_login,
    'user_password' => $password,
    'remember'      => true
    );

$user = wp_signon( $creds, false );
if ( is_wp_error( $user ) ) {
  $result = array('msg' =>"The username is not registered on this site.", 'Status'=> 201);
}else{
 /* wp_clear_auth_cookie();
  wp_set_current_user ( $user->ID ); 
  wp_set_auth_cookie  ( $user->ID ); */
  $result = array('msg' =>"Logged in successfully", 'Status'=> 200, 'UserID' => $user->ID);
}
return new WP_REST_Response($result, 200);
}

/*---------------------------end login api ----------------------------------------------*/

function showFavorites_callback( $request_data ) {
    global $wpdb;
    $table        = 'wp_posts';
    $parameters = $request_data->get_params();
    $post_type = $parameters['post_type'];

    if($post_type!=''){
      $re_query   = "SELECT * FROM $table where post_type='$post_type'";
      $pre_results  = $wpdb->get_results($re_query,ARRAY_A);   
      return $pre_results;

    }else{
      $data['status']=' false ';
      return $data;

    } 
}


function showFavorites_callback_userdata( $request_data ) {
global $wpdb;
$userprofile = array();
$parameters = $request_data->get_params();
$userID = $parameters['userID'];

$user_info = get_user_meta($userID);
$nickname = $user_info['nickname'][0];
$first_name = $user_info['first_name'][0];
$last_name = $user_info['last_name'][0];

$userprofile = array('nickname' => $nickname,
'first_name'=> $first_name);
return $userprofile;
}


function showFavorites_callback_updateprofile( $request_data ) {
global $wpdb;

$parameters = $request_data->get_params();
$userID = $parameters['userID'];

/*get value in wp*/
$user_info = get_user_meta($userID);

if( !empty( $parameters['nickname'] )) {
 $nickname = $parameters['nickname'];
}else{
 $nickname = $user_info['nickname'][0];
}

if( !empty( $parameters['first_name'] )) {
 $first_name = $parameters['first_name'];
}else{
 $first_name = $user_info['first_name'][0];
}

if( !empty( $parameters['last_name'] )) {
 $last_name = $parameters['last_name'];
}else{
 $last_name = $user_info['last_name'][0];
}

$metas = array( 
    'nickname'   => $nickname,
    'first_name' => $first_name, 
    'last_name'  => $last_name 
);

foreach($metas as $key => $value) {
  update_user_meta( $userID, $key, $value );
}

$data['status']='true';
return $data;
return new WP_REST_Response($data, 200);
}


function showFavorites_callback_passwordreset( $request_data ) {
global $wpdb;
$parameters = $request_data->get_params();

$userID = $parameters['userID'];
$password = $parameters['password'];
$mypassword = wp_hash_password($password);
$updatepassword = $wpdb->query("UPDATE wp_users SET user_pass = '".$mypassword."' WHERE ID = ".$userID." LIMIT 1");

if($updatepassword){
$result['status']=' true ';
return new WP_REST_Response($result, 200);
}else{
$result['status']=' false ';
return new WP_REST_Response($result, 201);
}

}

/*function hvuhvyi($request){
    $result = array("status"=>"success","errormsg"=>"",'error_code'=>"");
    $param = $request->get_params();

    $result['status'] = "error";
    $result['errormsg'] = "This is not found.";
    $result['errormsg'] = "This is not found.";
    $result['data'] = array();

    return new WP_REST_Response($result, 200);
}*/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

function showFavorites_callback_productlis($request_data){
global $wpdb;
global $post;
global $product;
$parameters = $request_data->get_params();

 $args = array(
        'post_type'      => 'product',
        'posts_per_page' => -1,
    );
$arr= array();
$gal =array();
    $loop = new WP_Query( $args );
    //print_r( $loop);
    while ( $loop->have_posts() ) : $loop->the_post(); 
    $product = wc_get_product( get_the_ID() );
    //print_r($product);

    $get_regular_price = $product->get_regular_price();
    $get_sale_price = $product->get_sale_price();
    $get_price = $product->get_price();

    $stock_status = $product->get_stock_status(); 
    $get_tax_status = $product->get_tax_status();
     $get_sku =  $product->get_sku(); 


        $featured_Image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' );
        $category = get_the_terms( get_the_ID(), 'product_cat' );

      if( !empty( $product->get_gallery_image_ids()) ){
       $attachment_ids = $product->get_gallery_image_ids();

        foreach( $attachment_ids as $attachment_id ) {
          $imageurl =   wp_get_attachment_url( $attachment_id );
          $gal[] = array('gallery_images_url' =>$imageurl);
        }
    }else{
        $gal[] = array('gallery_images_url' => false);
    }

        $arr[] = array(
                'post_title' => get_the_title(),
                'Product ID' => get_the_ID(), 
                'post_excerpt'=> get_the_excerpt(),
                'post_content' => get_the_content(),
                'post_status'=> get_post_status(),
                'post_date'=> get_the_date(),
                'get_regular_price' => $get_regular_price,

                'get_sku' => $get_sku,
                'stock_status' => $stock_status,
                'get_tax_status' => $get_tax_status,
                'featured_Image' => $featured_Image[0],
                'category_name' => $category,
                'gallery_images' => $gal
         );
        endwhile;
    wp_reset_query();
return $arr;
}


function showFavorites_callback_categorylist(){
$orderby = 'name';
$order = 'asc';
$hide_empty = false ;
$cat_args = array(
    'orderby'    => $orderby,
    'order'      => $order,
    'hide_empty' => $hide_empty,
);

$product_categories = get_terms( 'product_cat', $cat_args );
print_r($product_categories);
}


}
